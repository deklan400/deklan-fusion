#!/bin/bash

set +euo pipefail
# shellcheck disable=SC1090
source ~/.profile
set -euo pipefail

pip install --upgrade pip

